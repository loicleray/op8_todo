import './input.css'; //import css files which include tailwind css
const { factoryTodoTask } = require('./tasks.js');
const { factoryTodoProject } = require('./projects.js');
const { appStorage } = require('./app_storage.js');
const { DM } = require('./docMan.js');
const { getCurrentDateTime } = require('./dateTimeTool.js');

// const dateControl = document.querySelector('input[type="datetime-local"]');
// dateControl.value = getCurrentDateTime();
// dateControl.min = getCurrentDateTime();

// simpleTodo3.changeCompleteStatus()

// folder.addTodo(simpleTodo3)
// folder.editName("The new name, bruh.")
// folder.removeTodo(simpleTodo)

// console.log(simpleTodo)
// console.log(simpleTodo.id)
// console.log(simpleTodo.dueDate)
// console.log(simpleTodo2)
// console.log(simpleTodo3)
// console.log(folder)

// console.log(folder)
